#include <noeud.h>


/* Numero */

extern 
int noeud_numero_lire( const noeud_t * noeud ) 
{
  /***********
   * A FAIRE *
   ***********/
  return(0) ; 
}

extern 
err_t noeud_numero_ecrire( noeud_t * noeud , const int numero ) 
{
  /***********
   * A FAIRE *
   ***********/
  return(OK) ; 
}

/* Etiquette */

extern 
void * noeud_etiquette_lire( const noeud_t * noeud ) 
{
  /***********
   * A FAIRE *
   ***********/
  return(NULL) ; 
}

extern 
err_t noeud_etiquette_ecrire( noeud_t * noeud , 
			      void * etiquette ,
			      err_t (*affecter)( void * e1 , void * e2 ) ) 
{
  /***********
   * A FAIRE *
   ***********/
  return(OK) ; 
}

/* Sous arbre gauche */

extern 
noeud_t * noeud_sag_lire( const noeud_t * noeud ) 
{
  /***********
   * A FAIRE *
   ***********/
  return(NULL) ; 
}

extern 
err_t noeud_sag_ecrire( noeud_t * noeud ,  noeud_t * sous_arbre_gauche ) 
{
  /***********
   * A FAIRE *
   ***********/
  return(OK) ; 
}

/* Sous arbre droit */

extern 
noeud_t * noeud_sad_lire( const noeud_t * noeud ) 
{
  /***********
   * A FAIRE *
   ***********/
  return(NULL) ; 
}

extern 
err_t noeud_sad_ecrire( noeud_t * noeud ,  noeud_t * sous_arbre_droit ) 
{
  /***********
   * A FAIRE *
   ***********/
  return(OK) ; 
}

/*
 * Existance ?
 */

booleen_t
noeud_existe( const noeud_t * noeud )
{
  /***********
   * A FAIRE *
   ***********/
  return(FAUX) ; 
}

/* 
 * Feuille ?
 */
extern 
booleen_t noeud_feuille( const noeud_t * noeud )
{
  /***********
   * A FAIRE *
   ***********/
  return(FAUX) ; 
}

/* 
 * Parents ?
 */

extern
booleen_t noeud_est_pere( const noeud_t * noeud_pere , 
			  const noeud_t * noeud_fils ) 
{
  /***********
   * A FAIRE *
   ***********/
  return(FAUX) ; 
}

/* 
 * Creation
 */

extern 
noeud_t * noeud_creer( const int numero , 
		       void * etiquette , 
		       noeud_t * sous_arbre_gauche ,
		       noeud_t * sous_arbre_droit ,
		       err_t (*affecter)( void * e1 , void * e2 ) )
{
  noeud_t * noeud = NULL ; 
  
  /***********
   * A FAIRE *
   ***********/
 
  return( noeud ) ;
}

/*
 * Destruction 
 */

extern 
err_t noeud_detruire( noeud_t ** noeud , 
		      err_t (*detruire)( void * e) ) 
{
  /***********
   * A FAIRE *
   ***********/
 
  return(OK) ; 
}

/*
 * Affichage 
 */

extern
void noeud_afficher( const noeud_t * noeud ,
		     void (*afficher)(const void *) ) 
{
  /***********
   * A FAIRE *
   ***********/ 
}

/*
 * Sauvegarde dans un fichier 
 */

extern 
err_t noeud_fd_sauver( noeud_t * noeud  ,	                  /* Noeud a sauvegarder */
		       FILE * fd , 		                  /* Descripteur fichier  */
		       err_t (*sauver)( void * e, FILE *  desc) ) /* Fonction de sauvegarde d'un element */
{
  err_t noerr = OK ;

  if( ! noeud_existe( noeud ) ) 
    return(OK) ; 

  fprintf( fd , "%d " , noeud->numero ) ;
  noeud_t * fils_gauche  = noeud_sag_lire( noeud ) ;
  noeud_t * fils_droit   = noeud_sad_lire( noeud ) ;

  if( noeud_existe( fils_gauche ) )
    fprintf( fd , "%d " ,  noeud_numero_lire(fils_gauche) ) ; 
  else
    fprintf( fd , "-1 " ) ; 

  if( noeud_existe( fils_droit ) )
    fprintf( fd , "%d " ,  noeud_numero_lire(fils_droit) ) ; 
  else
    fprintf( fd , "-1 " ) ; 

  if( ( noerr = sauver( noeud->etiquette , fd ) ) )
    return(noerr) ; 

  return(OK) ; 
}

/*
 * Recherches d'un noeud dans un arbre 
 */


/* Sur le numero */

extern
booleen_t noeud_numero_rechercher( noeud_t ** result ,        /* Resultat: @ du noeud trouve */  
				   noeud_t * racine ,  /* Racine de l'arbre de recherche */
				   const int numero       )  /* Numero a rechercher dans l'arbre */
{
  /***********
   * A FAIRE *
   ***********/
  return(FAUX) ; 
}


/* Sur l'etiquette */

extern
booleen_t noeud_rechercher( noeud_t ** result ,			 /* Resultat: @ du noeud trouve */  
			    noeud_t * racine  ,	         /* Racine de l'arbre de recherche */
			    void * etiquette     ,		 /* Valeur a rechercher dans l'arbre */
			    int (*comparer)(void * n1 , void * n2) ) /* Fonction de comparaison des etiquettes */
{
  /***********
   * A FAIRE *
   ***********/
  return(FAUX) ; 
}
