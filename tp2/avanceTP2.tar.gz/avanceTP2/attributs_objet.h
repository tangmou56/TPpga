void(*afficher)(void *);
err_t(*detruire)(void **);
